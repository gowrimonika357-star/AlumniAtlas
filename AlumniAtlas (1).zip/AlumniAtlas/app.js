/* AlumniAtlas – plain JavaScript, no frameworks. Sections are numbered to match the page. */
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const MAX_PENDING = 3;      // anti-spam rule from the brief
const MIN_NOTE = 20;        // minimum characters in the request note
const RECENT_FROM = 2020;   // batches from this year get a small "recent graduate" bonus
const COLORS = ["#176e68", "#c2410c", "#6b5bd2", "#8a5d00", "#2c6fbb", "#b0407a"]; // all pass 4.5:1 with white text
const STOP = new Set(["the", "and", "for", "with", "want", "need", "how", "get", "into", "about", "help", "learn", "from", "that", "this", "can", "you", "are", "my", "me", "to", "in", "on", "of", "a", "i"]);

// SECURITY: every piece of text that goes into innerHTML passes through esc() so typed HTML can never run.
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- 1. PREPARE DATA ---------- */
// Turn raw rows into objects and build lowercase word lists for fast search and matching.
const words = text => String(text).toLowerCase().split(/[\s,]+/).filter(Boolean);
const alumni = RAW_ALUMNI.map((a, id) => {
  const [name, year, major, company, title, track, city, skills] = a;
  return { id, name, year, major, company, title, track, city, skills,
    color: COLORS[id % COLORS.length],
    initials: name.split(" ").map(w => w[0]).join(""),
    bio: `${name.split(" ")[0]} graduated in ${year} and can help with ${skills}.`,   // company, city and major are already shown on the card
    tokens: words([name, year, major, company, title, track, city, skills].join(" ")),   // used by the directory search
    keywords: words([title, company, major, city, skills].join(" ")) };                   // used by the matching engine
});
const jobs = RAW_JOBS.map(([title, type, company, by, location, salary, desc], id) => ({ title, type, company, by, location, salary, desc, id }));

/* ---------- 2. SAVED DATA (localStorage) ---------- */
const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return Array.isArray(v) ? v : d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode / quota: app still works for this visit */ } };
const STATUSES = ["pending", "accepted", "declined"];
// Ignore damaged or hand-edited storage instead of crashing.
const cleanRequests = list => list.filter(r => r && alumni[r.mentorId] && STATUSES.includes(r.status));
let requests = cleanRequests(load("aa_requests", []));
let applied = load("aa_applied", []).filter(id => jobs[id]);
const state = { track: "", jobType: "All", mentor: null, match: null };
const pendingCount = () => requests.filter(r => r.status === "pending").length;

let toastTimer;
function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2800);
}

/* ---------- 3. DIRECTORY: SEARCH + FILTERS ---------- */
function searchAlumni() {
  const terms = $("#search").value.toLowerCase().split(/\s+/).filter(Boolean);
  const year = +$("#yearFilter").value, company = $("#companyFilter").value;
  return alumni.filter(a =>
    terms.every(w => a.tokens.some(t => t.includes(w))) &&      // every search word must match something
    (!state.track || a.track === state.track) &&
    (!year || a.year === year) && (!company || a.company === company));
}

// m (optional) = match info from the matching engine: { score, reason }
function alumniCard(a, m) {
  const sent = requests.find(r => r.mentorId === a.id && r.status !== "declined");
  const label = !sent ? "Request mentorship" : sent.status === "accepted" ? "Mentor accepted" : "Request sent";
  return `<article class="card">
    <div class="top"><div class="avatar" style="background:${a.color}" aria-hidden="true">${esc(a.initials)}</div>
      <div><h3>${esc(a.name)}</h3><div class="sub">Batch of ${a.year} · ${esc(a.major)}</div></div></div>
    <div><span class="badge">${esc(a.track)}</span><span class="badge gold">${esc(a.company)}</span></div>
    <strong>${esc(a.title)} <span class="sub">· ${esc(a.city)}</span></strong>
    ${m ? `<span class="score">Match score: ${m.score}</span><span class="sub">Why: ${esc(m.reason)}</span>` : ""}
    <p class="bio">${esc(a.bio)}</p>
    <button class="btn small dark" data-mentor="${a.id}" aria-label="${label}: ${esc(a.name)}" ${sent ? "disabled" : ""}>${label}</button>
  </article>`;
}

function renderDirectory() {
  const list = searchAlumni();
  $("#resultCount").textContent = `${list.length} of ${alumni.length} alumni found`;
  $("#clearBtn").hidden = !($("#search").value.trim() || $("#yearFilter").value || $("#companyFilter").value || state.track);
  $("#alumniGrid").innerHTML = list.map(a => alumniCard(a)).join("") ||
    `<p class="empty">No alumni match these filters. Try removing a word or choosing “All”.</p>`;
}

function syncChips(box, current, attr) {
  $$(`${box} .chip`).forEach(c => { const on = c.dataset[attr] === current; c.classList.toggle("on", on); c.setAttribute("aria-pressed", on); });
}

function setupFilters() {
  [...new Set(alumni.map(a => a.year))].sort((x, y) => y - x).forEach(y => $("#yearFilter").insertAdjacentHTML("beforeend", `<option>${y}</option>`));
  [...new Set(alumni.map(a => a.company))].sort().forEach(c => $("#companyFilter").insertAdjacentHTML("beforeend", `<option>${esc(c)}</option>`));
  $("#trackChips").innerHTML = ["All tracks", ...TRACKS].map((t, i) => `<button type="button" class="chip" data-track="${i ? esc(t) : ""}">${esc(t)}</button>`).join("");
  $("#matchTrack").innerHTML = TRACKS.map(t => `<option>${esc(t)}</option>`).join("");
  syncChips("#trackChips", state.track, "track");
  $("#trackChips").onclick = e => {
    const chip = e.target.closest(".chip"); if (!chip) return;
    state.track = chip.dataset.track; syncChips("#trackChips", state.track, "track"); renderDirectory();
  };
  ["#search", "#yearFilter", "#companyFilter"].forEach(s => $(s).addEventListener("input", renderDirectory));
  $("#clearBtn").onclick = () => {
    $("#search").value = ""; $("#yearFilter").value = ""; $("#companyFilter").value = ""; state.track = "";
    syncChips("#trackChips", "", "track"); renderDirectory(); $("#search").focus();
  };
}

/* ---------- 4. MATCHING ENGINE ---------- */
// Score = same track (+5) + each goal word found in their title/skills/company/major (+2) + recent graduate (+1)
// Ties are broken by the newer batch, then by name, so the order is always stable.
function wordHits(keywords, w) {
  const stem = w.length > 4 ? w.replace(/(ing|s)$/, "") : w;        // "interviews" / "interviewing" -> "interview"
  return keywords.some(k => w.length < 4 ? k === w : k.startsWith(stem)); // short words (ai, ml, sql) must match exactly
}
function findMatches(track, goal) {
  const goalWords = [...new Set(goal.toLowerCase().split(/[^a-z0-9+#&]+/).filter(w => w.length > 1 && !STOP.has(w)))];
  return alumni.filter(a => a.track === track).map(a => {
    const found = goalWords.filter(w => wordHits(a.keywords, w));
    const recent = a.year >= RECENT_FROM;
    const reason = ["same track", recent ? "recent graduate" : "", found.length ? `matches “${found.join("”, “")}”` : ""].filter(Boolean).join(" · ");
    return { a, score: 5 + (recent ? 1 : 0) + found.length * 2, reason };
  }).sort((x, y) => y.score - x.score || y.a.year - x.a.year || x.a.name.localeCompare(y.a.name)).slice(0, 3);
}
function renderMatches() {
  if (!state.match) { $("#matchGrid").innerHTML = `<p class="empty">Your top 3 mentors will appear here.</p>`; return; }
  const best = findMatches(state.match.track, state.match.goal);
  $("#matchGrid").innerHTML = best.map(m => alumniCard(m.a, m)).join("");
}
$("#matchForm").onsubmit = e => {
  e.preventDefault();
  state.match = { track: $("#matchTrack").value, goal: $("#matchGoal").value };
  renderMatches();
  toast(`Showing your top 3 ${state.match.track} mentors`);
};

/* ---------- 5. MENTORSHIP REQUEST MODAL ---------- */
const modal = $("#modal"), form = $("#requestForm");
function showError(msg, field) {
  const box = $("#formError"); box.textContent = msg; box.hidden = !msg;
  $$("#requestForm [aria-invalid]").forEach(f => f.removeAttribute("aria-invalid"));
  if (field) { $(field).setAttribute("aria-invalid", "true"); $(field).focus(); }
}
function noteHint() {
  const n = $("#note").value.trim().length;
  $("#noteHint").textContent = n >= MIN_NOTE ? `${n} characters ✓` : `${n} / ${MIN_NOTE} characters minimum`;
}
document.addEventListener("click", e => {
  const btn = e.target.closest("[data-mentor]");
  if (!btn || btn.disabled) return;
  if (pendingCount() >= MAX_PENDING)
    return toast(`You already have ${MAX_PENDING} pending requests. Wait for a reply first.`);
  state.mentor = alumni[+btn.dataset.mentor];
  $("#mentorName").textContent = state.mentor.name;
  form.reset(); showError(""); noteHint();
  modal.showModal();
});
$("#note").addEventListener("input", noteHint);
$("#cancelBtn").onclick = () => modal.close();
modal.addEventListener("click", e => {          // clicking the dark backdrop closes the dialog
  if (e.target !== modal) return;
  const r = modal.getBoundingClientRect();
  if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) modal.close();
});
form.onsubmit = e => {
  e.preventDefault();
  const goal = $("#goal").value, topics = $("#topics").value.trim(), note = $("#note").value.trim(), mentor = state.mentor;
  if (!goal) return showError("Please choose a goal.", "#goal");
  if (!topics) return showError("Please add at least one topic to discuss.", "#topics");
  if (note.length < MIN_NOTE) return showError(`Your note needs at least ${MIN_NOTE} characters (you have ${note.length}).`, "#note");
  // Re-check the rules at send time too, in case another tab changed the saved data.
  if (pendingCount() >= MAX_PENDING) return showError(`You already have ${MAX_PENDING} pending requests. Wait for a reply first.`);
  if (requests.some(r => r.mentorId === mentor.id && r.status !== "declined")) return showError(`You have already asked ${mentor.name} for mentorship.`);
  requests.unshift({ id: Date.now(), mentorId: mentor.id, goal, topics, method: $("#method").value, note, status: "pending", created: Date.now() });
  save("aa_requests", requests);
  modal.close();
  toast(`Request sent to ${mentor.name}`);
  renderAll();
  $(".pill").focus({ preventScroll: true });     // the button that opened the modal was re-drawn, so keep keyboard focus somewhere sensible
};

/* ---------- 6. REQUEST STATUS (accept / decline) ---------- */
const fmtDate = t => new Date(t).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
function renderRequests() {
  $("#reqCount").textContent = pendingCount();
  $("#pendingNow").textContent = pendingCount();
  $("#requestList").innerHTML = requests.map(r => {
    const m = alumni[r.mentorId], first = esc(m.name.split(" ")[0]);
    const followUp = r.status === "accepted" ? `<p class="reply ok">${first} accepted. Expect a ${esc(r.method.toLowerCase())} invite soon.</p>`
      : r.status === "declined" ? `<p class="reply no">${first} can’t take this on right now. Try another ${esc(m.track)} mentor from the <a href="#directory">directory</a>.</p>` : "";
    return `<div class="req">
      <div><strong>${esc(m.name)}</strong> · ${esc(m.title)}, ${esc(m.company)} <span class="status ${r.status}">— ${r.status}</span></div>
      <div class="sub">${fmtDate(r.created)} · ${esc(r.goal)} · ${esc(r.method)} · Topics: ${esc(r.topics)}</div>
      <p>${esc(r.note)}</p>${followUp}
      <div class="row">${r.status === "pending"
        ? `<button class="btn small" data-reply="accepted" data-id="${r.id}" aria-label="Accept request to ${esc(m.name)} as mentor">Accept as mentor</button>
           <button class="btn small danger" data-reply="declined" data-id="${r.id}" aria-label="Decline request to ${esc(m.name)} as mentor">Decline as mentor</button>` : ""}
        <button class="btn small ghost" data-del="${r.id}" aria-label="Remove request to ${esc(m.name)}">Remove</button></div></div>`;
  }).join("") || `<p class="empty">No requests yet. Choose a mentor in the directory and send your first one.</p>`;
}
$("#requestList").onclick = e => {
  const b = e.target.closest("[data-reply], [data-del]"); if (!b) return;
  if (b.dataset.reply) {
    const r = requests.find(r => r.id == b.dataset.id); if (!r) return;
    r.status = b.dataset.reply; toast(`Request ${r.status}`);
  } else requests = requests.filter(r => r.id != b.dataset.del);
  save("aa_requests", requests); renderAll();
};

/* ---------- 7. JOB BOARD ---------- */
function renderJobs() {
  $("#jobGrid").innerHTML = jobs.filter(j => state.jobType === "All" || j.type === state.jobType).map(j => {
    const done = applied.includes(j.id), poster = alumni[j.by];
    return `<article class="card">
      <div><span class="badge gold">${esc(j.type)}</span><span class="badge">📍 ${esc(j.location)}</span></div>
      <h3>${esc(j.title)}</h3>
      <div class="sub">${esc(j.company)} · Posted by ${esc(poster.name)} (Batch of ${poster.year})</div>
      <p class="bio">${esc(j.desc)}</p>
      <strong>${esc(j.salary)}</strong>
      <button class="btn small" data-apply="${j.id}" aria-label="${done ? "Applied" : "Apply now"}: ${esc(j.title)} at ${esc(j.company)}" ${done ? "disabled" : ""}>${done ? "Applied ✓" : "Apply now"}</button>
    </article>`;
  }).join("") || `<p class="empty">No openings in this category yet.</p>`;
}
// The chips are built once (not on every render) so keyboard focus stays on the chip you just used.
$("#jobChips").innerHTML = ["All", "Internship", "Full-time"].map(t => `<button type="button" class="chip" data-jt="${t}">${t}</button>`).join("");
syncChips("#jobChips", state.jobType, "jt");
$("#jobChips").onclick = e => {
  const chip = e.target.closest(".chip"); if (!chip) return;
  state.jobType = chip.dataset.jt; syncChips("#jobChips", state.jobType, "jt"); renderJobs();
};
$("#jobGrid").onclick = e => {
  const b = e.target.closest("[data-apply]"); if (!b || b.disabled) return;
  const job = jobs[+b.dataset.apply];
  if (!applied.includes(job.id)) { applied.push(job.id); save("aa_applied", applied); }
  toast(`Applied to ${job.title} at ${job.company}`); renderJobs();
};

/* ---------- 8. STORIES ---------- */
$("#storyGrid").innerHTML = STORIES.map(s => `
  <article class="card story"><span class="badge gold">${esc(s.tag)}</span>
    <h3>${esc(s.title)}</h3><p>${esc(s.text)}</p><div class="sub">${esc(s.who)}</div></article>`).join("");

/* ---------- 9. START THE APP ---------- */
function renderAll() { renderDirectory(); renderMatches(); renderRequests(); renderJobs(); }
// Numbers on the page come from the data, so they can never go out of date.
$("#heroCount").textContent = $("#statAlumni").textContent = alumni.length;
$("#statTracks").textContent = TRACKS.length;
$("#statJobs").textContent = jobs.length;
$("#maxPending").textContent = MAX_PENDING;
// If the app is open in two tabs, keep them in sync.
window.addEventListener("storage", e => {
  if (e.key === "aa_requests") requests = cleanRequests(load("aa_requests", []));
  else if (e.key === "aa_applied") applied = load("aa_applied", []).filter(id => jobs[id]);
  else return;
  renderAll();
});
setupFilters(); renderAll();
