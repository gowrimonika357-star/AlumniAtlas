// SAMPLE DATA – edit freely. Counts on the page (alumni, tracks, openings) are calculated from this file.
const TRACKS = ["Software Engineering", "Data Science", "Product", "Core Engineering", "Finance"];

// Alumni: [name, batch, major, company, job title, career track, city, skills]
const RAW_ALUMNI = [
["Ananya Rao",2020,"Computer Science","Microsoft","Product Manager","Product","Hyderabad","product strategy, APM interviews, roadmaps"],
["Rohan Mehta",2018,"Computer Science","Google","Software Engineer","Software Engineering","Bengaluru","system design, DSA, backend"],
["Priya Nair",2021,"Information Technology","Amazon","SDE II","Software Engineering","Chennai","distributed systems, Java, cloud"],
["Karthik Iyer",2016,"Computer Science","Microsoft","Senior Engineer","Software Engineering","Hyderabad","Azure, career growth, mentoring"],
["Sneha Kulkarni",2019,"Electronics","Google","Data Scientist","Data Science","Bengaluru","machine learning, statistics, Python"],
["Arjun Reddy",2022,"Computer Science","Amazon","Applied Scientist","Data Science","Hyderabad","deep learning, research, NLP"],
["Meera Joshi",2017,"Mathematics","Goldman Sachs","Associate","Finance","Mumbai","investment banking, valuation, Excel"],
["Vikram Singh",2014,"Mechanical","Tata Steel","Plant Engineering Lead","Core Engineering","Jamshedpur","manufacturing, GATE, operations"],
["Divya Menon",2023,"Computer Science","Zerodha","Frontend Engineer","Software Engineering","Bengaluru","JavaScript, fintech, UI engineering"],
["Aditya Verma",2015,"Economics","Goldman Sachs","Vice President","Finance","Mumbai","markets, interviews, CFA"],
["Nisha Patel",2020,"Computer Science","Flipkart","Product Manager","Product","Bengaluru","e-commerce, user research, metrics"],
["Rahul Gupta",2019,"Civil","L&T","Project Engineer","Core Engineering","Chennai","construction, site planning, project management"],
["Ishita Bose",2024,"Computer Science","Google","Associate Product Manager","Product","Hyderabad","APM program, case interviews, product design"],
["Sanjay Kumar",2018,"Electrical","Siemens","Power Systems Engineer","Core Engineering","Pune","power electronics, automation, higher studies"],
["Pooja Desai",2021,"Statistics","Amazon","Data Analyst","Data Science","Bengaluru","SQL, dashboards, analytics careers"],
["Harsha Vardhan",2022,"Computer Science","Zerodha","Backend Engineer","Software Engineering","Bengaluru","Go, trading systems, open source"],
["Tanvi Shah",2017,"Finance","JP Morgan","Analyst","Finance","Mumbai","equity research, resume review, MBA"],
["Manoj Pillai",2016,"Mechanical","Mahindra","Design Engineer","Core Engineering","Pune","CAD, automotive, EV design"],
["Lakshmi Narayan",2014,"Computer Science","Microsoft","Principal Engineer","Software Engineering","Redmond","architecture, leadership, startups"],
["Aarav Kapoor",2023,"Computer Science","Razorpay","Data Scientist","Data Science","Bengaluru","fraud detection, ML projects, Kaggle"],
["Shreya Banerjee",2019,"Computer Science","Microsoft","Group Product Manager","Product","Redmond","AI products, career transitions, leadership"],
["Nikhil Rao",2020,"Electronics","Qualcomm","Hardware Engineer","Core Engineering","Hyderabad","VLSI, chip design, internships"],
["Kavya Reddy",2018,"Commerce","Zerodha","Product Analyst","Finance","Bengaluru","retail investing, product analytics"],
["Imran Sheikh",2021,"Computer Science","Google","Machine Learning Engineer","Data Science","Zurich","ML systems, MLOps, working abroad"],
["Deepa Krishnan",2015,"Computer Science","Amazon","Engineering Manager","Software Engineering","Seattle","management, promotion, interviews"],
["Yash Agarwal",2022,"Economics","Goldman Sachs","Analyst","Finance","Bengaluru","campus placements, financial modelling"],
["Ritika Sen",2024,"Information Technology","Razorpay","Product Associate","Product","Bengaluru","fintech, startups, first job advice"],
["Gautam Naidu",2017,"Chemical","Reliance","Process Engineer","Core Engineering","Mumbai","process design, plant safety, core jobs"],
["Sana Fatima",2019,"Computer Science","Flipkart","Data Scientist","Data Science","Bengaluru","recommendation systems, A/B testing"],
["Tarun Bhat",2016,"Computer Science","Microsoft","Product Manager","Product","Bengaluru","B2B SaaS, PM interviews, growth"]
];

// Jobs: [title, type, company, posted by (index in RAW_ALUMNI – must work at the same company), location, salary, description]
const RAW_JOBS = [
["APM Internship","Internship","Microsoft",0,"Hyderabad","₹80,000 / month","Six-month Associate Product Manager internship. Work with a real product team on a live feature."],
["Software Engineering Intern","Internship","Google",1,"Bengaluru","₹1,00,000 / month","Build backend features with a Google team. Strong DSA needed."],
["Graduate Software Engineer","Full-time","Amazon",2,"Chennai","₹24 – 30 LPA","Entry-level SDE role on a high-scale retail platform."],
["Data Science Intern","Internship","Razorpay",19,"Bengaluru","₹60,000 / month","Work on fraud models using real payment data."],
["Investment Banking Analyst","Full-time","Goldman Sachs",9,"Mumbai","₹22 – 28 LPA","Join the analyst programme and work on live deals."],
["Frontend Engineer (New Grad)","Full-time","Zerodha",8,"Bengaluru","₹12 – 18 LPA","Build fast, simple trading interfaces used by millions."],
["Design Engineer Trainee","Full-time","Mahindra",17,"Pune","₹7 – 10 LPA","Join the EV platform team as a trainee."],
["Product Analyst Intern","Internship","Flipkart",10,"Bengaluru","₹45,000 / month","Analyse customer funnels and help shape the roadmap."],
["VLSI Design Intern","Internship","Qualcomm",21,"Hyderabad","₹50,000 / month","Support a chip verification team for six months."],
["Machine Learning Associate","Full-time","Google",4,"Bengaluru","₹26 – 32 LPA","Ship ML models to production with a mentor."]
];

const STORIES = [
{tag:"Startup journey",who:"Lakshmi Narayan, Batch of 2014",title:"From campus hostel to a startup exit",text:"Lakshmi built a small scheduling tool in third year, joined Microsoft, then co-founded a startup that was acquired in 2022. He now returns to big-company engineering as a Principal Engineer, and his advice is simple: ship early and ask for feedback often."},
{tag:"Career switch",who:"Shreya Banerjee, Batch of 2019",title:"How an engineer became a product leader",text:"Shreya spent two years coding before moving to product. She says the secret was talking to users every single week and learning to say no."},
{tag:"Breaking into finance",who:"Meera Joshi, Batch of 2017",title:"A maths major on Dalal Street",text:"Without a finance degree, Meera learnt valuation on her own, built a portfolio of stock models, and joined Goldman Sachs, where she is now an Associate."}
];
