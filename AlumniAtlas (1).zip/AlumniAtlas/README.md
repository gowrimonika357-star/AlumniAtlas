# AlumniAtlas – MentorMatch

A mentorship and jobs platform for a university alumni community. Students search alumni, get ranked mentor matches, send mentorship requests, and apply to openings posted only by alumni.

Plain HTML, CSS and JavaScript – **no frameworks, no build step, no installs.** Open `index.html` in any modern browser.

## Features

| Section | What it does |
|---|---|
| **Alumni directory** | 30 alumni. Multi-word search across name, company, role, skills, city, batch (e.g. `microsoft product`). Filter by batch, company and career track. Clear-all button and live result count. |
| **Career track matching** | Pick a track and describe your goal. Returns the top 3 mentors with a **score and the reason** for each match. |
| **Mentorship requests** | Modal form with validation (goal, topics, 20+ character note). Max **3 pending requests** at a time, no duplicate requests to the same mentor. Accept/decline buttons simulate the mentor's reply. |
| **Job & internship board** | 10 openings, each posted by an alumnus of that company. Filter by type, apply with one click. |
| **Alumni stories** | 3 featured stories. |

Requests and applications are saved in `localStorage`, so they survive a page refresh.

## How matching works

```
score = 5            same career track (required)
      + 1            recent graduate (batch 2020 or later)
      + 2 per word   goal word found in the mentor's title, skills, company, major or city
```
Common filler words are ignored, `interview` matches `interviews`, and ties are broken by newer batch then name, so results are always stable.

## Files

```
index.html   page structure (7 numbered sections)
style.css    design tokens, layout, responsive rules
data.js      sample alumni, jobs, stories and tracks  <- edit this to change content
app.js       search, matching, requests, jobs (sections numbered like the page)
```

## Quality notes

- **Responsive:** 1 / 2 / 3 column grid; tested from 320px to 1600px with no horizontal scrolling.
- **Accessible:** labelled form controls, skip link, keyboard-operable filters with `aria-pressed`, live regions for results and toasts, visible focus rings, text colours checked against WCAG AA (4.5:1), `prefers-reduced-motion` respected.
- **Secure:** all user-typed text is HTML-escaped before display, so a note like `<img onerror=…>` is shown as text and never runs.
- **Robust:** damaged or edited `localStorage` is ignored instead of crashing; rules are re-checked when a request is sent.
- Stats on the hero (alumni / tracks / openings) are calculated from `data.js`, so they never go out of date.

## Browser support
Current Chrome, Edge, Firefox and Safari (uses the native `<dialog>` element).
